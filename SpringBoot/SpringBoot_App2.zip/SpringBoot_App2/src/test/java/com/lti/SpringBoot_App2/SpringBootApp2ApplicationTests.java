package com.lti.SpringBoot_App2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootApp2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
