package com.lti.SpringBoot_REST_StudentApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestStudentAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestStudentAppApplication.class, args);
	}

}
