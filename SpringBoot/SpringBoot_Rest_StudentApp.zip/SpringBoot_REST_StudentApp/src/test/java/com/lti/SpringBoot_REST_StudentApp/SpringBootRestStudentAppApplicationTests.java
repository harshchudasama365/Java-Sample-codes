package com.lti.SpringBoot_REST_StudentApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestStudentAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
